=== Covoituristes ===
Contributors: Covoituristes.fr
Donate link: http://www.covoituristes.fr
Tags: covoiturage, carpooling, carpool, rideshare, covoituristes
Requires at least: 2.7.0
Tested up to: 4.2.3
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Covoiturage pour votre site WordPress. Covoiturez vos événements. Solution 100% intégrée dans votre site. 
== Description ==
Covoiturage pour votre site WordPress. Covoiturez vos événements. Solution 100% intégrée dans votre site. 

<ul>
<li>
	<strong>Hyper facile</strong>
		<ol>
			<li>Activez le plugin WordPress (gratuit).</li>
			<li>Rien à changer à votre fichiers PHP !</li>
		</ol>
</li>
<li>
	<strong>Solution 100% intégrée</strong>
		<ol>
			<li>Vos visiteurs restent sur votre site. </li>
			<li>Aucune interference avec votre configuration existante.</li>
			<li>A base de standards ouverts du web.</li>
		</ol>
</li>

<li>
	<strong>Enfin une solution Covoiturage qui marche</strong>
		<ol>
			<li>Le covoiturage est offert directement sur votre site, pas dans un environnement commercial et anonyme.</li>
			<li>Une solution sans procédure d'enregistrement fastidieuse</li>
			<li>Il n'est pas nécessaire d'ouvrir un compte ni de publier des données privées.</li>
			<li>100% gratuit pour tous les usagers.</li>
		</ol>
</li>

<li>
	<strong>Seulement 25 &euro; par an.</strong>
		<ol>
			<li>1 mois d'essai gratuit.</li>
			<li>100% gratuit pour tous les usagers (offre ou demande de covoiturage).</li>
			<li>Il n'y a aucune charge sur votre serveur, puisque toutes les demandes sont traitées sur nos serveurs.</li>
			<li>Mises à jour et mises à niveau sans aucun souci pour vous.</li>
		</ol>
</li>


<li>
    <strong>Compatible</strong>
        <ol>
            <li>Le covoiturage marche sur n'importe quel ordinateur de bureau...</li>
            <li>et sur n'importe quel navigateur, sur n'importe quel appareil.</li>
            <li>Windows, Linux, Apple, PC, Macbook, iPad, iPhone, Android onglets, smartphones, etc.</li>
            <li>'Mobile first responsive design'.</li>
        </ol>
</li>

</ul>


== Installation ==

<h3>PLUGIN</h3>

1. Connectez vous au WordPress Tableau de bord, selectez l'option 'Extensions' et cliquez 'Ajouter'.
1. Lancez une recherche de le terme 'covoituristes' et Lorsque vous avez trouvé celle qui vous convient faites Installer maintenant. Une fois mise en place, il ne vous reste plus alors qu’à l’activer dans le menu Extensions puis Extensions installées.

<h3>L’installation manuelle</h3>

1. Téléchargez `covoituristes4wp.zip` de http://www.covoituristes.fr/covoituristes4wp.zip
1. Près avoir téléchargé votre extension au format  ZIP il vous suffit de vous rendre dans l’interface d’administration, dans Extensions puis Ajouter. Sélectionnez l’onglet Envoyer et sélectionnez l’archive contenant votre extension. Il sera alors automatiquement téléchargé et installé dans le répertoire wp-content/plugins de votre installation WordPress. Il ne vous reste plus qu’à l’activer la dans l’interface d’administration, dans le menu Extensions puis Extensions installées où elle devrait apparaître.

== Frequently Asked Questions ==

= Je ne vois pas aucune changement =

Nous non plus.

= Ou est-ce que je peux demander quelque chose ? =

Pour le F.A.Q. et pour SUPPORT svp utilisez l'option 'Support' dans l'application sur [www.covoituristes.fr](http://www.covoituristes.fr/ "Ask a question"), 


== Screenshots ==

1. Une fenêtre intégrée dans votre site web.
2. Le tableau de bord - les options.
3. Le tableau de bord - la gestion des événements.
4. Le schema, comment ça marche ?

== Changelog ==

= 1.0 =
* 2015 Aout.
* 2nd release of this WordPress plugin.

= 0.1 =
* 2014 Nov.
* First release of this Covoituristes.fr WordPress plugin.

== Upgrade Notice ==

= 0.1 =
* 2014 Nov.
* First release of this Covoituristes.fr WordPress plugin.
